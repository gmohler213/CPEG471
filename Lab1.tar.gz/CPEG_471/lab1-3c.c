void main(int argc, char **argv){
	int x = 3;
}

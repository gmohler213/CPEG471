#include <stdio.h>

int adder(int a, int b){
	int sum = a+b;
	return sum;
}

void main(int argc, char **argv){
	printf("%d\n", adder(3, 5));
}
